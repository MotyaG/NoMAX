#!/system/bin/sh
MODDIR=${0%/*}

BLACKLIST="$MODDIR/blacklist.txt"
MODE="delete"

while true; do
    for PKG in $(cat $BLACKLIST); do
        if pm list packages | grep -q "$PKG"; then
            if [ "$MODE" = "delete" ]; then
                log -t NoMAX "удаляем $PKG"
                pm uninstall --user 0 $PKG
            elif [ "$MODE" = "crash" ]; then
                log -t NoMAX "крашим $PKG"
                # Завершаем процесс приложения
                PID=$(pidof $PKG)
                if [ ! -z "$PID" ]; then
                    kill -9 $PID
                    log -t NoMAX "крашим $PKG (PID=$PID)"
                fi
            fi
        fi
    done
    sleep 2
done
